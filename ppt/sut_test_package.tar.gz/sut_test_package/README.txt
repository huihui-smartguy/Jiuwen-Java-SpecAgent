===================================================================
 AutoTestFlow - SUT 配置变更自动测试包
===================================================================

【目录结构】
  run_me.sh           - 入口脚本（一键启动）
  run_tests.sh        - 测试引擎（422行，带超时保护）
  case_manifest.json  - 35个用例参数清单（配置操作 + 判定规则）
  results/            - 测试结果输出目录（自动创建）

【前置条件】
  1. 在执行机上运行（Docker 宿主机）
  2. SUT 容器正在运行（默认容器名: edp-agent）
  3. 安装了: docker, curl, timeout, python3

【运行方式】
  cd sut_test_package/
  bash run_me.sh

  如需指定不同容器名或 SUT 地址:
  CONTAINER=my-edp SUT_URL=http://10.0.0.1:8190 bash run_me.sh

【运行过程】
  每个用例执行 4 个步骤:
  1. 恢复原始配置（从备份）
  2. 应用目标配置（修改 YAML）
  3. 重启容器，等待启动
  4. 判定结果（检查容器状态 + /health 端点）
  

【结果文件】
  测试完成后，results/ 目录包含:
  ├── summary.json              ← 【核心】最终统计: 总数/通过/失败/跳过
  ├── results.jsonl             ← 每个用例的判定详情
  ├── step_log.txt              ← 全流程步骤日志（最详细）
  ├── full_output.log           ← 完整终端输出
  ├── TC-XXX_container.log      ← 每个用例的容器日志
  └── backup_original/          ← 原始配置备份（自动恢复用）

【用例分类】
  批次1 (7例): 场景切换              TC-003/004/036/037/038/044/104
  批次2 (4例): Governance 边界       TC-006/007/018/082
  批次3 (6例): Fail-Fast 模型校验    TC-011/012/077/078/079/085
  批次4 (8例): Fail-Fast 其他校验    TC-013/041/042/043/080/081/084/099
  批次5 (5例): 沙箱+Redis+LLM边界   TC-009/010/014/017/083
  批次6 (5例): 交叉/基线/特殊        TC-015/019/046/076/105

【测试完成后】
  请将 results/ 目录整个打包发回:
  tar czf results.tar.gz results/
  
  然后把 results/step_log.txt 和 results/summary.json 的内容发给我
  我会据此更新最终报告。
===================================================================
