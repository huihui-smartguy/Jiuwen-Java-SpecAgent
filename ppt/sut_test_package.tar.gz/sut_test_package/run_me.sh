#!/bin/bash
# =============================================================================
# AutoTestFlow SUT 配置测试 - 一键启动
# 用法: bash run_me.sh
# 环境变量（可选）:
#   CONTAINER=edp-agent        Docker 容器名
#   SUT_URL=http://127.0.0.1:8190  SUT 地址
# =============================================================================
set -e

cd "$(dirname "$0")"
echo "============================================"
echo " AutoTestFlow - 35 个 SUT 配置用例自动测试"
echo "============================================"
echo ""
echo "工作目录: $(pwd)"
echo "容器:     ${CONTAINER:-edp-agent}"
echo "SUT URL:  ${SUT_URL:-http://127.0.0.1:8190}"
echo "结果目录: ./results/"
echo ""
echo "预计耗时: 15-20 分钟"
echo "============================================"
echo ""

chmod +x run_tests.sh

bash run_tests.sh 2>&1 | tee ./results/full_output.log

echo ""
echo ">>> 测试完成，结果请查看 ./results/ 目录 <<<"
echo "   summary.json      - 汇总统计"
echo "   results.jsonl     - 逐用例结果"
echo "   step_log.txt      - 步骤详细日志"
echo "   *_container.log   - 容器日志"
