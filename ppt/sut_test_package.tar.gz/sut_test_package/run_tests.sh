#!/bin/bash
# =============================================================================
# SUT 配置变更自动测试引擎 v2.0
# 所有操作带超时保护，详细步骤日志，JSON 结果输出
# =============================================================================
set -o pipefail

########## 可覆盖的环境变量 ##########
CONTAINER="${CONTAINER:-edp-agent}"
SUT_URL="${SUT_URL:-http://127.0.0.1:8190}"
WAIT_START="${WAIT_START:-15}"
WAIT_FAIL="${WAIT_FAIL:-8}"
RESULT_DIR="${RESULT_DIR:-./results}"
MANIFEST="${MANIFEST:-./case_manifest.json}"
STEP_LOG="${RESULT_DIR}/step_log.txt"

# 容器内路径
APP_YML="/app/config/application.yml"
GOV_DIR="/app/config/governance"
SCENE_DIR="/app/scenarios"

mkdir -p "$RESULT_DIR"

########## 日志函数 ##########
ts() { date '+%Y-%m-%dT%H:%M:%S'; }
log()   { echo "[$(ts)] $*" | tee -a "$STEP_LOG"; }
ok()    { echo "   [OK] $*" | tee -a "$STEP_LOG"; }
err()   { echo "  [ERR] $*" | tee -a "$STEP_LOG"; }
skip()  { echo " [SKIP] $*" | tee -a "$STEP_LOG"; }
die()   { err "$*"; exit 1; }

########## 工具函数（全部带超时） ##########

# 执行 docker 命令，带 10 秒超时
drun() {
    timeout 10 docker "$@" 2>&1 || true
}

# 执行 docker exec，带超时
dexec() {
    timeout 10 docker exec "$CONTAINER" "$@" 2>&1 || true
}

# 容器内 sed 修改 YAML
dosed() {
    local key="$1"   # 如 "scenario-home"
    local val="$2"   # 如 "wealth-demo"
    timeout 5 docker exec "$CONTAINER" sh -c \
        "sed -i \"s|^\\([[:space:]]*${key}[[:space:]]*:[[:space:]]*\\).*|\\1 ${val}|\" ${APP_YML}" 2>&1 || true
}

# 容器内注释 YAML key（整行注释）
docomment() {
    local key="$1"
    timeout 5 docker exec "$CONTAINER" sh -c \
        "sed -i \"s|^\\([[:space:]]*${key}[[:space:]]*:.*\\)|#\\1|\" ${APP_YML}" 2>&1 || true
}

# 容器内取消注释
douncomment() {
    local key="$1"
    timeout 5 docker exec "$CONTAINER" sh -c \
        "sed -i \"s|^#[[:space:]]*\\([[:space:]]*${key}[[:space:]]*:.*\\)|\\1|\" ${APP_YML}" 2>&1 || true
}

# 容器内写文件
dowrite() {
    local dest="$1"
    local content="$2"
    echo "$content" | timeout 5 docker exec -i "$CONTAINER" sh -c "cat > $dest" 2>&1 || true
}

# 健康检查（带超时）
health() {
    local t="${1:-3}"
    timeout "$t" curl -s -o /dev/null -w "%{http_code}" --connect-timeout "$t" "${SUT_URL}/health" 2>/dev/null || echo "000"
}

# 容器是否在运行
running() {
    timeout 3 docker inspect --format='{{.State.Running}}' "$CONTAINER" 2>/dev/null || echo "unknown"
}

# 重启容器
restart_sut() {
    log "  重启容器..."
    timeout 20 docker restart "$CONTAINER" >/dev/null 2>&1 || {
        # 尝试 docker compose restart
        timeout 20 docker compose restart 2>/dev/null || true
    }
}

# 备份当前配置
backup_orig() {
    local tag="$1"
    local d="$RESULT_DIR/backup_${tag}"
    mkdir -p "$d"
    timeout 10 docker cp "$CONTAINER:$APP_YML" "$d/application.yml" 2>/dev/null && ok "已备份 application.yml" || err "备份 application.yml 失败"
    if timeout 3 docker exec "$CONTAINER" test -d "$GOV_DIR" 2>/dev/null; then
        timeout 10 docker cp "$CONTAINER:$GOV_DIR" "$d/governance" 2>/dev/null && ok "已备份 governance/" || err "备份 governance/ 失败"
    fi
    if timeout 3 docker exec "$CONTAINER" test -d "$SCENE_DIR" 2>/dev/null; then
        timeout 10 docker cp "$CONTAINER:$SCENE_DIR" "$d/scenarios" 2>/dev/null && ok "已备份 scenarios/" || err "备份 scenarios/ 失败"
    fi
    echo "$d"
}

# 恢复配置
restore_orig() {
    local d="$1"
    if [ -f "$d/application.yml" ]; then
        timeout 10 docker cp "$d/application.yml" "$CONTAINER:$APP_YML" 2>/dev/null && ok "已恢复 application.yml" || err "恢复 application.yml 失败"
    fi
    if [ -d "$d/governance" ]; then
        timeout 5 docker exec "$CONTAINER" rm -rf "$GOV_DIR" 2>/dev/null || true
        timeout 10 docker cp "$d/governance/." "$CONTAINER:$GOV_DIR" 2>/dev/null && ok "已恢复 governance/" || err "恢复 governance/ 失败"
    fi
    if [ -d "$d/scenarios" ]; then
        timeout 5 docker exec "$CONTAINER" rm -rf "$SCENE_DIR" 2>/dev/null || true
        timeout 10 docker cp "$d/scenarios/." "$CONTAINER:$SCENE_DIR" 2>/dev/null && ok "已恢复 scenarios/" || err "恢复 scenarios/ 失败"
    fi
}

# 获取容器日志尾部
grab_logs() {
    local case_id="$1"
    timeout 5 docker logs --tail 80 "$CONTAINER" > "${RESULT_DIR}/${case_id}_container.log" 2>&1
}

# 记录单条结果到 JSON
record() {
    local cid="$1" status="$2" detail="$3" evidence="$4"
    echo "  {\"case_id\":\"$cid\",\"status\":\"$status\",\"detail\":\"$detail\",\"evidence\":\"$evidence\"}," >> "${RESULT_DIR}/results.jsonl"
}

########## 配置操作解释器 ##########
apply_config() {
    local ops="$1"
    if [ "$ops" = "none" ]; then
        log "  无需修改配置"
        return 0
    fi

    # 按 ; 分割多个操作
    IFS=';' read -ra parts <<< "$ops"
    for part in "${parts[@]}"; do
        part=$(echo "$part" | xargs)  # trim
        [ -z "$part" ] && continue

        log "  执行: $part"

        case "$part" in
            yaml_set\ *)
                # yaml_set <key> <value>
                local key=$(echo "$part" | awk '{print $2}')
                local val=$(echo "$part" | cut -d' ' -f3- | sed "s/^'//;s/'$//")
                dosed "$key" "$val"
                ;;
            yaml_comment\ *)
                # yaml_comment <key>
                local key=$(echo "$part" | awk '{print $2}')
                docomment "$key"
                ;;
            yaml_uncomment\ *)
                local key=$(echo "$part" | awk '{print $2}')
                douncomment "$key"
                ;;
            gov_actrule\ *)
                # gov_actrule <json_array>
                local arr=$(echo "$part" | cut -d' ' -f2-)
                # 把 Python 风格的数组转成 YAML 列表
                local yaml_list=$(echo "$arr" | sed "s/'/\"/g" | python3 -c "
import sys,json
arr=json.loads(sys.stdin.read())
for item in arr:
    print(f'  - {item}')
" 2>/dev/null)
                local yaml_content="allowed_tools:\n${yaml_list}"
                dowrite "${GOV_DIR}/actrule.yaml" "$(printf "$yaml_content")"
                ;;
            mkdir_empty_scene\ *)
                # mkdir_empty_scene <scene_name>
                local sname=$(echo "$part" | awk '{print $2}')
                timeout 5 docker exec "$CONTAINER" sh -c "
                    mkdir -p ${SCENE_DIR}/${sname}
                    rm -rf ${SCENE_DIR}/${sname}/governance 2>/dev/null || true
                " 2>&1 || true
                ok "已创建空场景: ${sname}"
                ;;
            *)
                err "未知配置操作: $part"
                return 1
                ;;
        esac
    done
    return 0
}

########## 判定逻辑 ##########
judge() {
    local cid="$1" expect="$2"

    # 等待容器状态稳定
    sleep 3

    local r=$(running)
    local hc=$(health 5)
    local status="fail"
    local detail=""
    local evidence=""

    case "$expect" in
        fail)
            # 预期失败：容器退出 或 health 不可达
            if [ "$r" = "false" ]; then
                status="pass"
                detail="容器已退出（符合 fail-fast 预期）"
                evidence="container_exited"
            elif [ "$hc" != "200" ] && [ "$hc" != "000" ]; then
                status="pass"
                detail="health=${hc}（预期非 200）"
                evidence="health_not_ok"
            elif [ "$hc" = "000" ]; then
                status="pass"
                detail="health 不可达（符合 fail-fast 预期）"
                evidence="health_unreachable"
            else
                status="fail"
                detail="预期 fail-fast 但容器正常运行（health=${hc}）"
                evidence="unexpected_healthy"
            fi
            ;;
        ok)
            if [ "$r" = "true" ] && [ "$hc" = "200" ]; then
                status="pass"
                detail="容器 running + health 200 OK"
                evidence="running_healthy"
            elif [ "$r" = "true" ]; then
                # 启动成功但 health 非 200，也算通过（可能 API key 无效但不影响启动）
                status="pass"
                detail="容器 running（health=${hc}，可能是 API 层错误非启动错误）"
                evidence="running_health_${hc}"
            else
                status="fail"
                detail="预期正常运行但容器退出（running=${r}）"
                evidence="unexpected_stopped"
            fi
            ;;
        skip)
            status="skip"
            detail="该用例需代码级扩展，跳过"
            evidence="code_level_only"
            ;;
    esac

    # 记录日志
    grab_logs "$cid"

    # 更新步骤日志
    if [ "$status" = "pass" ]; then
        ok "$cid: $detail"
    elif [ "$status" = "skip" ]; then
        skip "$cid: $detail"
    else
        err "$cid: $detail"
        # 失败时额外记录关键日志行
        local key_logs=$(grep -iE "error|exception|Illegal|fail|校验" "${RESULT_DIR}/${cid}_container.log" 2>/dev/null | head -5 || true)
        if [ -n "$key_logs" ]; then
            echo "  --- 关键日志 ---" | tee -a "$STEP_LOG"
            echo "$key_logs" | tee -a "$STEP_LOG"
        fi
    fi

    record "$cid" "$status" "$detail" "$evidence"
    return 0
}

########## 主流程 ##########
main() {
    echo "" > "$STEP_LOG"
    echo '{"results":[' > "${RESULT_DIR}/results.jsonl"
    log "========================================="
    log " SUT 配置变更自动测试引擎 v2.0"
    log " 时间: $(ts)"
    log " 容器: $CONTAINER"
    log " SUT:  $SUT_URL"
    log " 清单: $MANIFEST"
    log "========================================="

    # 前置检查
    log ""
    log ">>> 前置检查 <<<"
    if ! command -v docker >/dev/null 2>&1; then die "未找到 docker 命令"; fi
    if ! command -v timeout >/dev/null 2>&1; then die "未找到 timeout 命令"; fi

    local r=$(running)
    local hc=$(health 5)
    log "容器状态: running=$r  health=$hc"
    if [ "$r" != "true" ]; then
        die "容器 $CONTAINER 未运行，请先启动 SUT"
    fi

    # 备份原始配置
    log ""
    log ">>> 备份原始配置 <<<"
    ORIG_BAK=$(backup_orig "original")
    log "备份位置: $ORIG_BAK"

    # 逐用例执行
    local TOTAL=0 PASSED=0 FAILED=0 SKIPPED=0
    local cases=$(python3 -c "
import json
with open('$MANIFEST') as f:
    d = json.load(f)
for c in d['cases']:
    print(c['id'])
" 2>/dev/null)

    if [ -z "$cases" ]; then
        die "无法解析 case_manifest.json，请确认文件存在且格式正确"
    fi

    for cid in $cases; do
        TOTAL=$((TOTAL + 1))
        # 读取该用例的配置
        local info=$(python3 -c "
import json
with open('$MANIFEST') as f:
    d = json.load(f)
for c in d['cases']:
    if c['id'] == '$cid':
        print(json.dumps(c))
        break
" 2>/dev/null)

        local name=$(echo "$info" | python3 -c "import sys,json; print(json.loads(sys.stdin.read()).get('name',''))" 2>/dev/null)
        local expect=$(echo "$info" | python3 -c "import sys,json; print(json.loads(sys.stdin.read()).get('expect','ok'))" 2>/dev/null)
        local ops=$(echo "$info" | python3 -c "import sys,json; print(json.loads(sys.stdin.read()).get('config','none'))" 2>/dev/null)
        local note=$(echo "$info" | python3 -c "import sys,json; print(json.loads(sys.stdin.read()).get('note',''))" 2>/dev/null)

        log ""
        log "========================================="
        log " [$TOTAL/35] $cid - $name"
        log " 预期: $expect | $note"
        log "========================================="

        # 恢复原始配置
        restore_orig "$ORIG_BAK"
        sleep 2

        # 应用配置
        apply_config "$ops" || {
            record "$cid" "fail" "配置应用失败" "config_apply_error"
            FAILED=$((FAILED + 1))
            continue
        }

        # 重启
        restart_sut

        # 等待
        if [ "$expect" = "fail" ]; then
            log "  等待 ${WAIT_FAIL}s（fail-fast 模式）..."
            sleep "$WAIT_FAIL"
        else
            log "  等待 ${WAIT_START}s（正常启动）..."
            sleep "$WAIT_START"
        fi

        # 判定
        judge "$cid" "$expect"

        # 更新计数
        case "$status" in
            pass) PASSED=$((PASSED + 1)) ;;
            fail) FAILED=$((FAILED + 1)) ;;
            skip) SKIPPED=$((SKIPPED + 1)) ;;
        esac

        log "  [进度] 已测${TOTAL}/35  通过${PASSED}  失败${FAILED}  跳过${SKIPPED}"
    done

    # 恢复原始配置
    log ""
    log ">>> 恢复原始配置 <<<"
    restore_orig "$ORIG_BAK"
    restart_sut
    sleep "$WAIT_START"
    local final_hc=$(health 5)
    log "最终健康检查: $final_hc"

    # 写入最终汇总
    sed -i '' 's/,$//' "${RESULT_DIR}/results.jsonl" 2>/dev/null || sed -i 's/,$//' "${RESULT_DIR}/results.jsonl" 2>/dev/null || true
    echo ']}' >> "${RESULT_DIR}/results.jsonl"

    # 生成 summary.json
    cat > "${RESULT_DIR}/summary.json" << EOF
{
  "timestamp": "$(ts)",
  "container": "$CONTAINER",
  "sut_url": "$SUT_URL",
  "total": $TOTAL,
  "passed": $PASSED,
  "failed": $FAILED,
  "skipped": $SKIPPED,
  "backup_dir": "$ORIG_BAK"
}
EOF

    log ""
    log "========================================="
    log "           测 试 完 成"
    log "========================================="
    log " 总计: $TOTAL | 通过: $PASSED | 失败: $FAILED | 跳过: $SKIPPED"
    log " 结果: ${RESULT_DIR}/results.jsonl"
    log " 汇总: ${RESULT_DIR}/summary.json"
    log " 日志: ${RESULT_DIR}/step_log.txt"
    log "========================================="
}

main "$@"
